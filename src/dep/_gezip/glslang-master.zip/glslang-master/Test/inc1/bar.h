float4 i2;

#include "foo.h"
